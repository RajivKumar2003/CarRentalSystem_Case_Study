package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import dao.CarLeaseRepositoryImpl;
import entity.*;
import util.DBConnUtil;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CarRentalSystemTest {

	static CarLeaseRepositoryImpl repo;
	static Connection testConnection;

	@BeforeAll
	public static void setup() throws Exception {
		testConnection = DBConnUtil.getConnection();
		repo = new CarLeaseRepositoryImpl(testConnection);
		System.out.println("Setup completed");
	}

	@AfterAll
	public static void teardown() throws Exception {
		if (testConnection != null && !testConnection.isClosed()) {
			testConnection.close();
			System.out.println("Connection closed");
		}
	}

	@Test
	@Order(1)
	public void testAddCar() throws Exception {
		System.out.println("\n[Test 1] Starting testAddCar");

		Vehicle car = new Vehicle(0, "TestMake", "TestModel", 2022, 500.0, "available", 5, 1.2);
		assertTrue(repo.addCar(car));

		List<Vehicle> available = repo.listAvailableCars();
		boolean found = false;
		int carId = -1;

		for (Vehicle v : available) {
			if (v.getMake().equals("TestMake")) {
				carId = v.getVehicleID();
				found = true;
				break;
			}
		}
		assertTrue(found);
		assertTrue(repo.removeCar(carId));

		System.out.println("[Test 1 Passed] testAddCar completed.");
	}

	@Test
	@Order(2)
	public void testRemoveCar() throws Exception {
		System.out.println("\n[Test 2] Starting testRemoveCar");

		Vehicle car = new Vehicle(0, "DeleteMake", "DeleteModel", 2021, 400.0, "available", 4, 1.0);
		repo.addCar(car);

		List<Vehicle> cars = repo.listAvailableCars();
		int carId = cars.get(cars.size() - 1).getVehicleID();

		assertTrue(repo.removeCar(carId));

		List<Vehicle> updatedList = repo.listAvailableCars();
		for (Vehicle v : updatedList) {
			assertNotEquals(carId, v.getVehicleID());
		}

		System.out.println("[Test 2 Passed] testRemoveCar completed.");
	}

	@Test
	@Order(3)
	public void testAddCustomer() throws Exception {
		System.out.println("\n[Test 3] Starting testAddCustomer");

		String email = "test_" + UUID.randomUUID() + "@example.com";
		Customer customer = new Customer(0, "Test", "User", email, "9876543210");
		assertTrue(repo.addCustomer(customer));

		List<Customer> list = repo.listCustomers();
		boolean found = false;
		int id = -1;

		for (Customer c : list) {
			if (c.getEmail().equals(email)) {
				id = c.getCustomerID();
				found = true;
				break;
			}
		}
		assertTrue(found);
		assertTrue(repo.removeCustomer(id));

		System.out.println("[Test 3 Passed] testAddCustomer completed.");
	}

	@Test
	@Order(4)
	public void testRemoveCustomer() throws Exception {
		System.out.println("\n[Test 4] Starting testRemoveCustomer");

		String email = "del_" + UUID.randomUUID() + "@example.com";
		Customer customer = new Customer(0, "Del", "Cust", email, "9998887770");
		repo.addCustomer(customer);

		List<Customer> list = repo.listCustomers();
		int id = list.get(list.size() - 1).getCustomerID();

		assertTrue(repo.removeCustomer(id));

		List<Customer> updatedList = repo.listCustomers();
		for (Customer c : updatedList) {
			assertNotEquals(id, c.getCustomerID());
		}

		System.out.println("[Test 4 Passed] testRemoveCustomer completed.");
	}

	@Test
	@Order(5)
	public void testCreateAndEndLease() throws Exception {
		System.out.println("\n[Test 5] Starting testCreateAndEndLease");

		String email = "lease_" + UUID.randomUUID() + "@example.com";
		Customer cust = new Customer(0, "Lease", "Guy", email, "1112223333");
		repo.addCustomer(cust);
		int custId = repo.listCustomers().get(repo.listCustomers().size() - 1).getCustomerID();

		Vehicle car = new Vehicle(0, "LeaseCar", "ModelX", 2023, 800, "available", 4, 1.5);
		repo.addCar(car);
		int carId = repo.listAvailableCars().get(repo.listAvailableCars().size() - 1).getVehicleID();

		String start = LocalDate.now().toString();
		String end = LocalDate.now().plusDays(10).toString();

		Lease lease = repo.createLease(custId, carId, start, end, "Daily");
		assertNotNull(lease);

		repo.endLease(lease.getLeaseID());

		boolean found = repo.listLeaseHistory().stream()
			.anyMatch(l -> l.getLeaseID() == lease.getLeaseID());

		assertTrue(found);

		repo.removeCustomer(custId);
		repo.removeCar(carId);

		System.out.println("[Test 5 Passed] testCreateAndEndLease completed.");
	}

	@Test
	@Order(6)
	public void testRecordPayment() throws Exception {
		System.out.println("\n[Test 6] Starting testRecordPayment");

		String email = "pay_" + UUID.randomUUID() + "@example.com";
		Customer cust = new Customer(0, "Pay", "User", email, "9998887776");
		repo.addCustomer(cust);
		int custId = repo.listCustomers().get(repo.listCustomers().size() - 1).getCustomerID();

		Vehicle car = new Vehicle(0, "PayCar", "ModelZ", 2023, 900, "available", 4, 1.6);
		repo.addCar(car);
		int carId = repo.listAvailableCars().get(repo.listAvailableCars().size() - 1).getVehicleID();

		String start = LocalDate.now().toString();
		String end = LocalDate.now().plusDays(4).toString();
		Lease lease = repo.createLease(custId, carId, start, end, "Daily");

		repo.recordPayment(lease.getLeaseID(), 2000.0);

		boolean found = repo.getPaymentHistory(custId).stream()
			.anyMatch(p -> p.getAmount() == 2000.0);

		assertTrue(found);

		repo.endLease(lease.getLeaseID());
		testConnection.createStatement().executeUpdate("DELETE FROM payment WHERE leaseID = " + lease.getLeaseID());
		testConnection.createStatement().executeUpdate("DELETE FROM lease WHERE leaseID = " + lease.getLeaseID());
		repo.removeCustomer(custId);
		repo.removeCar(carId);

		System.out.println("[Test 6 Passed] testRecordPayment completed.");
	}

	@Test
	@Order(7)
	public void testGetTotalRevenue() {
		System.out.println("\n[Test 7] Starting testGetTotalRevenue");
		double total = repo.getTotalRevenue();
		System.out.println("Total Revenue: Rs." + total);
		assertTrue(total >= 0.0);
	}

	@Test
	@Order(8)
	public void testListCustomers() {
		System.out.println("\n[Test 8] Starting testListCustomers");
		List<Customer> customers = repo.listCustomers();
		System.out.println("Total customers: " + customers.size());
		assertNotNull(customers);
	}

	@Test
	@Order(9)
	public void testListAvailableCars() {
		System.out.println("\n[Test 9] Starting testListAvailableCars");
		List<Vehicle> cars = repo.listAvailableCars();
		System.out.println("Available cars: " + cars.size());
		assertNotNull(cars);
	}

	@Test
	@Order(10)
	public void testListRentedCars() {
		System.out.println("\n[Test 10] Starting testListRentedCars");
		List<Vehicle> cars = repo.listRentedCars();
		System.out.println("Rented cars: " + cars.size());
		assertNotNull(cars);
	}

	@Test
	@Order(11)
	public void testListLeases() {
		System.out.println("\n[Test 11] Starting testListLeases");
		List<Lease> leases = repo.listLeases();
		System.out.println("Total leases: " + leases.size());
		assertNotNull(leases);
	}

	@Test
	@Order(12)
	public void testListActiveLeases() {
		System.out.println("\n[Test 12] Starting testListActiveLeases");
		List<Lease> leases = repo.listActive